/**
 * Implementation of the NetPIPE Protocol Interface for TCP.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.  You should have received a copy of the
 * GNU General Public License along with this program; if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * @author Guy Helmer
 * @version $Revision: 1.1 $
 */

import java.net.*;
import java.io.*;

public class TCPImpl implements ProtocolInterface {
  /**
   * Instantiate a TCP shim for NetPIPE.
   */
  public TCPImpl()
  {
    String str = "SyncMe";
    SyncBytes = str.getBytes();
  }

  /**
   * Return whether this process is the transmitter or the receiver.
   *
   * @return True if this is the transmitter.
   */
  public boolean isTransmitter()
  {
    if (trans == 1)
      return true;
    return false;
  }

  /**
   * Print the protocol-specific flags on standard error.
   */
  public void usage()
  {
    System.err.println("TCP-specific flags:");
    System.err.println("-h: specify hostname <-h host>");
    System.err.println("-p: specify port <-p port#>");
    System.err.println("-r: receiver");
    System.err.println("-t: transmitter");
  }

  /**
   * Review the string arguments for per-protocol flags.
   *
   * @param args - Array of Strings remaining for our perusal.
   * @return Array of Strings listing flags not used by the protocol.
   */
  public String[] ReadArguments(String[] args) throws IllegalArgumentException
  {
    String[] unusedArgs = new String[args.length];
    int unusedArgCount = 0;
    int i;

    for (i = 0; i < args.length; i++)
      {
	if (args[i].equals("-t"))
	  {
	    trans = 1;
	  }
	else if (args[i].equals("-r"))
	  {
	    trans = 0;
	  }
	else if (args[i].equals("-p"))
	  {
	    if ((i + 1) < args.length)
	      {
		try
		  {
		    port = Integer.parseInt(args[++i]);
		  }
		catch (NumberFormatException e)
		  {
		    throw new
		      IllegalArgumentException("Couldn't parse " + args[i] +
					       "as a number:" + e);
		  }
	      }
	    else
	      {
		throw new
		  IllegalArgumentException("-p specified without " +
					   "a port number.");
	      }
	  }
	else if (args[i].equals("-h"))
	  {
	    if ((i + 1) < args.length)
	      {
		try
		  {
		    remoteHost = InetAddress.getByName(args[++i]);
		  }
		catch (UnknownHostException e)
		  {
		    throw new
		      IllegalArgumentException("Host name " + args[i] +
					       "unknown:" + e);
		  }
	      }
	    else
	      {
		throw new
		  IllegalArgumentException("-h specified without " +
					   "a port number.");
	      }
	  }
	else
	  {
	    unusedArgs[unusedArgCount++] = args[i];
	  }
      }

    if (trans == -1)
      {
	throw new IllegalArgumentException("-t or -r must be specified");
      }

    String[] returnUnused = new String[unusedArgCount];
    for (i = 0; i < unusedArgCount; i++)
      {
	returnUnused[i] = unusedArgs[i];
      }
    return returnUnused;
  }

  /**
   * Setup the testing environment.  Create the TCP socket and
   * make the connection.
   */
  public void Setup() throws Exception
  {
    if (trans == 1)
      {
	if (remoteHost == null)
	  {
	    throw new Exception("Remote hostname not specified");
	  }
	try
	  {
	    s = new Socket(remoteHost, port);
	  }
	catch (IOException e)
	  {
	    throw new Exception("Couldn't create socket to remote host: " + e);
	  }
      }
    else
      {
	try
	  {
	    ServerSocket ss = new ServerSocket(port);
	    s = ss.accept();
	    ss.close();
	  }
	catch (IOException e)
	  {
	    throw new
	      Exception("Couldn't create or accept on ServerSocket: " + e);
	  }
      }
    try { s.setTcpNoDelay(true); }
    catch (SocketException e)
      {
	throw new Exception("Couldn't set TCP NODELAY: " + e);
      }
    try
      {
	sockIn = new DataInputStream(s.getInputStream());
	sockOut = new DataOutputStream(s.getOutputStream());
      }
    catch (IOException e)
      {
	throw new
	  Exception("I/O Error getting socket input and output streams: " + e);
      }
  }

  /**
   * Synchronize the two sides of the test.
   */
  public void Sync() throws IOException
  {
    byte[] response = new byte[SyncBytes.length];
    sockOut.write(SyncBytes);
    sockIn.readFully(response);

    boolean OK = true;
    int i;
    for (i = 0; i < SyncBytes.length; i++)
      {
	if (SyncBytes[i] != response[i])
	  {
	    OK = false;
	    break;
	  }
      }
    if (!OK)
      {
	throw new IOException("Syncronization string incorrect!");
      }
  }

  /**
   * Prepare to receive a block of data.  In the case of MPI, this
   * allows each side to setup a receiving buffer before the data is sent,
   * potentially allowing the system to receive directly to user space
   * for a big performance win.
   *
   * @param bytes - Array of bytes to contain received data.
   * @param length - Number of bytes to receive.
   */
  public void PrepareToReceive(byte[] bytes, int length) throws IOException
  {
    /* No preposted receive in TCP. */
  }

  /**
   * Send a block of data.
   *
   * @param bytes - Array of bytes containing data to be sent.
   * @param length - Number of bytes to send.
   */
  public void SendData(byte[] bytes, int length) throws IOException
  {
    sockOut.write(bytes, 0, length);
  }

  /**
   * Receive a block of data.
   *
   * @param bytes - Array of bytes to contain data to be sent.  If
   * PrepareToReceive was called to setup a receive buffer beforehand,
   * the preposted buffer and this buffer should be the same.
   * @param length - Number of bytes to receive.
   */
  public void RecvData(byte[] bytes, int length) throws IOException
  {
    sockIn.readFully(bytes, 0, length);
  }

  /**
   * Send the repetition count to the other side.
   *
   * @param repeat Repetition count.
   */
  public void SendRepeat(int repeat) throws IOException
  {
    sockOut.writeInt(repeat);
  }

  /**
   * Receive the repetition count from the other side.
   *
   * @return Integer containing repetition count from transmitter.
   */
  public int RecvRepeat() throws IOException
  {
    return sockIn.readInt();
  }

  /**
   * Send the current time to the other side, using microseconds
   * as the transmission format.
   *
   * @param dtime Time in seconds.
   */
  public void SendTime(double dtime) throws IOException
  {
    int usec;

    usec = (int)(dtime * 1.0E6);

    sockOut.writeInt(usec);
  }

  /**
   * Receive the other side's timestamp.
   *
   * @return Time in seconds.
   */
  public double RecvTime() throws IOException
  {
    double dtime;
    int usec;

    usec = sockIn.readInt();
    dtime = ((double) usec) / 1.0E6;
    return dtime;
  }

  /**
   * Cleanup closes down the link between the two processes.  For
   * example, TCP closes the sockets.
   */
  public void CleanUp()
  {
    sockIn = null;
    sockOut = null;
    try
      {
	s.close();
      }
    catch (IOException e)
      {
	/* Nothing... */
      }
    s = null;
  }

  public final static int DEFAULT_TCP_PORT=5002;

  private int trans=-1;			/* 1 if transmitting. */
  private InetAddress remoteHost=null;	/* Name of remote host. */
  private int port=DEFAULT_TCP_PORT;	/* Port to listen on or connect to. */
  private Socket s=null;		/* Network socket for connection. */
  private DataInputStream sockIn=null;	/* Socket input stream. */
  private DataOutputStream sockOut=null;/* Socket output stream. */
  private byte[] SyncBytes=null;	/* Synchronization string. */
}
