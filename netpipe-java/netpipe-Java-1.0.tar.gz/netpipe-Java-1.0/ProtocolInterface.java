/**
 * ProtocolInterface defines the interface required of protocol
 * implementations.
 *
 * @author Guy Helmer
 * @version $Revision: 1.1 $
 */

import java.io.IOException;

public interface ProtocolInterface {
  /**
   * Determine whether this process is the transmitter or the
   * receiver.
   *
   * @return True if this is the transmitter.
   */
  public boolean isTransmitter();
  /**
   * Print the protocol-specific flags on standard error.
   */
  public void usage();
  /**
   * Review the string arguments for per-protocol flags.
   *
   * @param args - Array of Strings remaining for our perusal.
   * @return Array of Strings listing flags not used by the protocol.
   */
  public String[] ReadArguments(String[] args) throws IllegalArgumentException;
  /**
   * Setup the testing environment.  For example, TCP would open
   * sockets and set any optional socket flags.  MPI would figure out
   * which process is the sender and which is the receiver.
   */
  public void Setup() throws Exception;
  /**
   * Synchronize the two sides of the test.
   */
  public void Sync() throws IOException;
  /**
   * Prepare to receive a block of data.  In the case of MPI, this
   * allows each side to setup a receiving buffer before the data is sent,
   * potentially allowing the system to receive directly to user space
   * for a big performance win.
   *
   * @param bytes - Array of bytes to contain received data.
   * @param length - Number of bytes to receive.
   */
  public void PrepareToReceive(byte[] bytes, int length) throws IOException;
  /**
   * Send a block of data.
   *
   * @param bytes - Array of bytes containing data to be sent.
   * @param length - Number of bytes to send.
   */
  public void SendData(byte[] bytes, int length) throws IOException;
  /**
   * Receive a block of data.
   *
   * @param bytes - Array of bytes to contain data to be sent.  If
   * PrepareToReceive was called to setup a receive buffer beforehand,
   * the preposted buffer and this buffer should be the same.
   * @param length - Number of bytes to receive.
   */
  public void RecvData(byte[] bytes, int length) throws IOException;
  /**
   * Send the repetition count to the other side.
   */
  public void SendRepeat(int repeat) throws IOException;
  /**
   * Receive the repetition count from the other side.
   */
  public int RecvRepeat() throws IOException;
  /**
   * Send the current time to the other side.
   */
  public void SendTime(double time) throws IOException;
  /**
   * Receive the other side's timestamp.
   */
  public double RecvTime() throws IOException;
  /**
   * Cleanup closes down the link between the two processes.  For
   * example, TCP closes the sockets.
   */
  public void CleanUp();
}
