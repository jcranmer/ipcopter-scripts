/**
 * NetPIPE Network Protocol Independent Performance Evaluator in Java
 * Copyright 1998 Iowa State University Research Foundation, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.  You should have received a copy of the
 * GNU General Public License along with this program; if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * @author Guy Helmer
 * @version $Revision: 1.4 $
 */

import java.io.*;
import corejava.Format;

public class Netpipe {
  /**
   * NetPIPE application entry point.  Instantiate this object
   * and execute the application.
   */
  public static void main(String[] args)
  {
    Netpipe NetPIPE = new Netpipe();
    NetPIPE.run(args);
  }
  /**
   * Empty constructor.
   */
  public Netpipe()
  {
  }
  /**
   * Actual entry point for NetPIPE.
   *
   * @param args - Array of arguments provided from the command line.
   */
  private void run(String[] args)
  {
    PrintStream out = System.out;

    int
      i, j,
      sampleCount,		/* Number of samples */
      nq,			/* Times through outer loop */
      nrepeat,			/* Number of time to do the transmission */
      length,			/* Number of bytes to be transmitted */
      pert;			/* Perturbation value */

    double t, t0, t1, t2,	/* Time variables */
      tlast,			/* Time for last transmission */
      latency;			/* Network message latency */

    double bwdata_t,		/* Per-sample values of time, bps, variance */
      bwdata_bps,
      bwdata_variance;
    int bwdata_bits,
      bwdata_repeat;

    byte[] buffer1, buffer2;	/* Send and receive buffers for data */
    int bufferLength;

    boolean transmitter;	/* Is this process the transmitter? */

    /* Attempt to load & instantiate the specified protocol class. */
    if (args.length < 1)
      {
	System.err.println("Protocol class (e.g., \"TCP\") must be first arg");
	usage();
	System.exit(1);
      }
    String protocol = args[0] + "Impl";
    ProtocolInterface PI = loadProtocol(protocol);

    processArgs(args, PI);

    try
      {
	PI.Setup();
      }
    catch (Exception e)
      {
	System.err.println("Could not setup protocol class " + protocol +
			   ": " + e);
	System.exit(1);
      }

    transmitter = PI.isTransmitter();

    PrintStream outputStream = System.out;
    if (transmitter)
      {
	/* Open output file. */
	FileOutputStream fos = null;
	try
	  {
	    fos = new FileOutputStream(outputFileName);
	  }
	catch (IOException e)
	  {
	    System.err.println("Error opening output file " + outputFileName +
			       ": " + e);
	    System.exit(6);
	  }
	outputStream = new PrintStream(fos);
      }

    try
      {
	bufferLength = 1;
	buffer1 = new byte[bufferLength];
	buffer2 = new byte[bufferLength];
	if (asyncReceive)
	  {
	    PI.PrepareToReceive(buffer2, bufferLength);
	  }
	PI.Sync();
	t0 = When();
	t0 = When();
	t0 = When();
	t0 = When();
	for (i = 0; i < LATENCYREPS; i++)
	  {
	    if (transmitter)
	      {
		PI.SendData(buffer1, bufferLength);
		PI.RecvData(buffer2, bufferLength);
		if (asyncReceive && (i < LATENCYREPS - 1))
		  {
		    PI.PrepareToReceive(buffer2, bufferLength);
		  }
	      }
	    else
	      {
		PI.RecvData(buffer2, bufferLength);
		if (asyncReceive && (i < LATENCYREPS - 1))
		  {
		    PI.PrepareToReceive(buffer2, bufferLength);
		  }
		PI.SendData(buffer1, bufferLength);
	      }
	  }
	latency = (When() - t0)/(2 * LATENCYREPS);

	if (transmitter)
	  {
	    PI.SendTime(latency);
	  }
	else
	  {
	    latency = PI.RecvTime();
	  }
	if (transmitter && printOption)
	  {
	    System.out.println("Latency: " + (new Format("%f")).form(latency));
	    System.out.println("Now starting main loop");
	  }
	tlast = latency;
	if (inc == 0)
	  {
	    /* Set a starting value for the message size increment. */
	    inc = (start > 1) ? start / 2 : 1;
	  }

	/* Main loop of benchmark */
	for (nq = sampleCount = 0, length = start;
	     sampleCount < NSAMP - 3 && tlast < STOPTM && length <= end;
	     length += inc, nq++)
	  {
	    if (nq > 2 && !detailFlag)
	      {
		/*
		  This has the effect of exponentially increasing the block
		  size.  If detailFlag is false, then the block size is
		  linearly increased (the increment is not adjusted).
		  */
		inc = (nq % 2 != 0) ? inc + inc : inc;
	      }
	    /* This is a perturbation loop to test nearby values */
	    for (pert = (!detailFlag && inc > PERT+1)? -PERT: 0;
		 pert <= PERT; 
		 sampleCount++,
		   pert += (!detailFlag && inc > PERT+1)? PERT: PERT+1)
	      {
		/* Calculate how many times to repeat the experiment. */
		if (transmitter)
		  {
		    nrepeat =
		      (int)MAX((RUNTM / ((double)bufferLength /
					 ((double)(bufferLength - inc) + 1.0)
					 * tlast)),
			       (double)TRIALS);
		    PI.SendRepeat(nrepeat);
		  }
		else
		  {
		    nrepeat = PI.RecvRepeat();
		  }

		/*
		  Drop references to previously-allocated buffers
		  to free the memory for reuse.
		  */
		buffer1 = null;
		buffer2 = null;
		/* Allocate the buffers. */
		bufferLength = length + pert;
		buffer1 = new byte[bufferLength];
		buffer2 = new byte[bufferLength];

		/*
		  There shouldn't be much memory allocation after this
		  point in the loop.  Try to minimize the effect of
		  garbage collection during timing by encouraging
		  garbage collection now.
		  G.c. in the loops, right before the timing started,
		  seemed to have a detrimental effect -- could it
		  be a separate thread?
		  */
		System.gc();

		/*
		  The original C code aligned the data buffers here.
		  Java thoroughly abstracts the data storage so that it
		  doesn't appear to be possible to align data buffers
		  to any particular meaningful boundary.
		  */

		if (transmitter && printOption)
		  {
		    /*fprintf(stderr,"%3d: %9d bytes %4d times --> ",
		      n, bufferLength, nrepeat);*/
		    System.err.print(intToStr(sampleCount, 3) + ": " +
				     intToStr(bufferLength, 9) + " bytes " +
				     intToStr(nrepeat, 4) + " times --> ");
		    System.err.flush();
		  }

		/* Finally, we get to transmit or receive and time */
		if (transmitter)
		  {
		    /*
		      This is the transmitter: send the block TRIALS times, and
		      if we are not streaming, expect the receiver to return
		      each block.
		      */
		    bwdata_t = LONGTIME;
		    t2 = t1 = 0;
		    for (i = 0; i < TRIALS; i++)
		      {
			PI.Sync();
			t0 = When();
			for (j = 0; j < nrepeat; j++)
			  {
			    if (asyncReceive && !streamOption)
			      {
				PI.PrepareToReceive(buffer2, bufferLength);
			      }
			    PI.SendData(buffer1, bufferLength);
			    if (!streamOption)
			      {
				PI.RecvData(buffer2, bufferLength);
			      }
			  }
			t = (When() - t0)/((streamOption ? 1 : 2) * nrepeat);

			if (!streamOption)
			  {
			    t2 += t*t;
			    t1 += t;
			    bwdata_t = MIN(bwdata_t, t);
			  }
		      }
		    if (!streamOption)
		      {
			PI.SendTime(bwdata_t);
		      }
		    else
		      {
			bwdata_t = PI.RecvTime();
		      }

		    if (!streamOption)
		      {
			bwdata_variance = t2/TRIALS - t1/TRIALS * t1/TRIALS;
		      }
		    else
		      {
			bwdata_variance = 0;
		      }

		  }
		else
		  {
		    /*
		      This is the receiver: receive the block TRIALS times, and
		      if we are not streaming, send the block back to the
		      sender.
		      */
		    bwdata_t = LONGTIME;
		    t2 = t1 = 0;
		    for (i = 0; i < TRIALS; i++)
		      {
			if (asyncReceive)
			  {
			    PI.PrepareToReceive(buffer2, bufferLength);
			  }
			PI.Sync();
			t0 = When();
			for (j = 0; j < nrepeat; j++)
			  {
			    PI.RecvData(buffer2, bufferLength);
			    if (asyncReceive && (j < nrepeat - 1))
			      {
				PI.PrepareToReceive(buffer2, bufferLength);
			      }
			    if (!streamOption)
			      {
				PI.SendData(buffer1, bufferLength);
			      }
			  }
			t = (When() - t0)/((streamOption ? 1 : 2) * nrepeat);

			if (streamOption)
			  {
			    t2 += t*t;
			    t1 += t;
			    bwdata_t = MIN(bwdata_t, t);
			  }
		      }
		    if (streamOption)
		      {
			PI.SendTime(bwdata_t);
		      }
		    else
		      {
			bwdata_t = PI.RecvTime();
		      }

		    if (streamOption)
		      {
			bwdata_variance = t2/TRIALS - t1/TRIALS * t1/TRIALS;
		      }
		    else
		      {
			bwdata_variance = 0;
		      }
		  }
		tlast = bwdata_t;
		bwdata_bits = bufferLength * CHARSIZE;
		bwdata_bps = bwdata_bits / (bwdata_t * 1024 * 1024);
		bwdata_repeat = nrepeat;

		if (transmitter)
		  {
		    /*
		      fprintf(out,"%lf %lf %d %d %lf\n",bwdata_t,bwdata_bps,
		      bwdata_bits, bwdata_bits / 8, bwdata_variance);
		      fflush(out);
		      */
		    Format pF = new Format("%f");
		    outputStream.println(pF.form(bwdata_t) + " " +
					 pF.form(bwdata_bps) + " " +
					 bwdata_bits + " " +
					 bwdata_bits/8 + " " +
					 pF.form(bwdata_variance));
		  }

		if (transmitter && printOption)
		  {
		    /*
		      fprintf(stderr," %6.2lf Mbps in %lf sec\n",
		      bwdata_bps,tlast);
		      */
		    Format mbpsF = new Format("%6.2f");
		    Format pF = new Format("%f");
		    System.err.println(" " + mbpsF.form(bwdata_bps) +
				       " Mbps in " + pF.form(tlast) + " sec");
		  }
	      } /* End of perturbation loop */
	  }
      }
    catch (IOException e)
      {
	System.err.println("I/O Error: " + e);
	System.exit(2);
      }
  }

  /**
   * Load the protocol interface.
   */
  public ProtocolInterface loadProtocol(String protocol)
  {
    Class PIC = null;
    try
      {
	PIC = Class.forName(protocol);
      }
    catch (ClassNotFoundException e)
      {
	System.err.println("ProtocolInterface implementation " + protocol +
			   "not found!");
	System.exit(2);
      }
    ProtocolInterface PI = null;
    try
      {
	PI = (ProtocolInterface) PIC.newInstance();
      }
    catch (InstantiationException e)
      {
	System.err.println("Exception instantiating " + protocol + ": " + e);
	System.exit(3);
      }
    catch (IllegalAccessException e)
      {
	System.err.println("Exception instantiating " + protocol + ": " + e);
	System.exit(3);
      }
    return PI;
  }

  /**
   * Process the command-line arguments.
   */
  private void processArgs(String[] args, ProtocolInterface PI)
  {
    /*
      Parse the arguments: hand the right n-1 args to the protocol-specific
      argument handler, then parse the remaining args for general options.
      */
    String[] xArgs = new String[args.length - 1];
    int i;
    for (i = 1; i < args.length; i++)
      {
	xArgs[i - 1] = args[i];
      }
    try
      {
	xArgs = PI.ReadArguments(xArgs);
      }
    catch (IllegalArgumentException e)
      {
	System.err.println("Error handling protocol-specific args: " + e);
	usage(PI);
	System.exit(4);
      }

    /* Examine remaining program arguments. */
    for (i = 0; i < xArgs.length; i++)
      {
	if (xArgs[i].equals("-o"))
	  {
	    if ((i + 1) < xArgs.length)
	      {
		outputFileName = xArgs[++i];
	      }
	  }
	else if (xArgs[i].equals("-s"))
	  {
	    streamOption = true;
	  }
	else if (xArgs[i].equals("-l"))
	  {
	    if ((i + 1) < xArgs.length)
	      {
		try
		  {
		    start = Integer.parseInt(xArgs[++i]);
		  }
		catch (NumberFormatException e)
		  {
		    System.err.println("Couldn't parse " + xArgs[i] + ": " +
				       e);
		    usage(PI);
		    System.exit(4);
		  }
	      }
	  }
	else if (xArgs[i].equals("-u"))
	  {
	    if ((i + 1) < xArgs.length)
	      {
		try
		  {
		    end = Integer.parseInt(xArgs[++i]);
		  }
		catch (NumberFormatException e)
		  {
		    System.err.println("Couldn't parse " + xArgs[i] + ": " +
				       e);
		    usage(PI);
		    System.exit(4);
		  }
	      }
	  }
	else if (xArgs[i].equals("-i"))
	  {
	    detailFlag = true;
	    if ((i + 1) < xArgs.length)
	      {
		try
		  {
		    inc = Integer.parseInt(xArgs[++i]);
		  }
		catch (NumberFormatException e)
		  {
		    System.err.println("Couldn't parse " + xArgs[i] + ": " +
				       e);
		    usage(PI);
		    System.exit(4);
		  }
	      }
	  }
	else if (xArgs[i].equals("-P"))
	  {
	    printOption = true;
	  }
	else if (xArgs[i].equals("-a"))
	  {
	    asyncReceive = true;
	  }
	else
	  {
	    System.err.println("Unknown option " + xArgs[i]);
	    usage(PI);
	    System.exit(4);
	  }
      }
    if (start > end)
      {
	System.err.println("Start must be less than End!");
	usage(PI);
	System.exit(4);
      }
  }

  /**
   * Return the current time in seconds.
   */
  private double When()
  {
    return (double)System.currentTimeMillis() / 1.0E3;
  }

  /**
   * Print the general flags on standard error.
   */
  private static void usage()
  {
    System.err.println("NetPIPE (Java) Usage:");
    System.err.println("-a: asynchronous receive (a.k.a. preposted receive)");
    System.err.println("-i: specify increment step size <-i inc>");
    System.err.println("-l: lower bound start value <-l startval>");
    System.err.println("-o: specify output filename <-o fn>");
    System.err.println("-P: print on screen");
    System.err.println("-s: stream option");
    System.err.println("-u: upper bound stop value <-u stopval>");
  }

  /**
   * Print the general flags on standard error and invoke protocol-specific
   * usage to print its usage as well.
   */
  private static void usage(ProtocolInterface PI)
  {
    usage();
    /*System.err.println("Protocol-specific flags:");*/
    PI.usage();
  }

  /**
   * Return the minimum of two doubles.
   */
  private static double MIN(double v1, double v2)
  {
    if (v1 < v2)
      return v1;
    return v2;
  }

  /**
   * Return the maximum of two doubles.
   */
  private static double MAX(double v1, double v2)
  {
    if (v1 > v2)
      return v1;
    return v2;
  }

  /**
   * Format an integer as a string with at least the specified number of
   * of positions in the output string.
   */
  private static String intToStr(int val, int digits)
  {
    int i;
    String result = "";
    boolean negative = (val < 0) ? true : false;

    val = (val < 0) ? -val : val;

    do
      {
	result = (new Integer(val % 10)).toString() + result;
	val /= 10;
	digits--;
      }
    while (val > 0);
    if (negative)
      {
	result = "-" + result;
	digits--;
      }
    while (digits-- > 0)
      {
	result = " " + result;
      }
    return result;
  }

  private boolean
    asyncReceive=false,/* Pre-post a receive buffer? */
    detailFlag=false,		/* Set to examine the signature curve detail */
    streamOption=false,		/* Streaming mode flag */
    printOption=false;		/* Debug print statements flag */
  private int
    inc=0,			/* Increment value */
    start=1,			/* Starting value for signature curve */
    end=Integer.MAX_VALUE;	/* Ending value for signature curve */
  private String outputFileName="netpipe.out";

  private static final int TRIALS = 7;	/* Minimum number of trials */
  private static final int NSAMP = 8000;/* Max samples to take */
  private static final int PERT = 3;	/* Pertubation factor */
  private static final int LATENCYREPS = 100; /* Number of loops for latency */
  private static final double LONGTIME = Double.MAX_VALUE;
  private static final int CHARSIZE = 8;/* Bits in a byte */
  private static final double RUNTM = 0.25; /* Desired time for test */
  private static final double STOPTM = 1.0; /* Stop when xfer time exceeds */
}
